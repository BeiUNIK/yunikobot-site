import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Check, Star, Zap, PenTool, Mail, BarChart3, Shield, ArrowRight } from 'lucide-react';

function App() {
  const [email, setEmail] = useState('');
  const [showSignup, setShowSignup] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('');

  const handleSignup = (plan: string) => {
    setSelectedPlan(plan);
    setShowSignup(true);
  };

  const submitEmail = async () => {
    if (!email) return;
    
    // Send to your API
    try {
      await fetch('https://my-api-iota-one.vercel.app/api/v1/leads/capture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          source: 'website',
          lead_magnet: selectedPlan || 'newsletter'
        })
      });
    } catch (e) {
      console.log('API call made');
    }
    
    setShowSignup(false);
    setShowSuccess(true);
    setEmail('');
  };

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
              <Zap className="h-6 w-6 text-indigo-600" />
              <span className="text-xl font-bold text-gray-900">YunikoBot</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <button onClick={() => scrollToSection('features')} className="text-gray-600 hover:text-gray-900 transition-colors">Features</button>
              <button onClick={() => scrollToSection('pricing')} className="text-gray-600 hover:text-gray-900 transition-colors">Pricing</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-gray-600 hover:text-gray-900 transition-colors">Testimonials</button>
            </div>
            <Button 
              className="bg-indigo-600 hover:bg-indigo-700"
              onClick={() => handleSignup('starter')}
            >
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <Badge className="mb-6 bg-indigo-100 text-indigo-700 hover:bg-indigo-100 cursor-default">
            🚀 Now with Telegram Notifications
          </Badge>
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">
            Create Content <span className="text-indigo-600">10x Faster</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            AI-powered content creation for creators, marketers, and businesses. 
            Generate blog posts, social media, and emails in minutes.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-indigo-600 hover:bg-indigo-700 text-lg px-8"
              onClick={() => handleSignup('starter')}
            >
              Start Free Trial <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg px-8"
              onClick={() => scrollToSection('features')}
            >
              See How It Works
            </Button>
          </div>
          
          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 max-w-2xl mx-auto">
            <div>
              <div className="text-4xl font-bold text-indigo-600">10K+</div>
              <div className="text-gray-500">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-indigo-600">1M+</div>
              <div className="text-gray-500">Articles Created</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-indigo-600">4.9/5</div>
              <div className="text-gray-500">User Rating</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need to Create Content at Scale
            </h2>
            <p className="text-xl text-gray-600">
              Powerful AI tools that help you produce high-quality content in a fraction of the time
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <PenTool className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>Blog Post Generator</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Create SEO-optimized blog posts of 2,500+ words in minutes. Includes research, outline, and full article.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <Zap className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>Social Media Posts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Generate engaging posts for Twitter, LinkedIn, and Instagram. Includes hashtags and optimal formatting.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <Mail className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>Email Sequences</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Write high-converting email sequences, newsletters, and cold outreach that gets responses.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <BarChart3 className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>SEO Optimization</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Built-in SEO tools ensure your content ranks. Keyword suggestions, meta descriptions, and readability analysis.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <Shield className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>Brand Voice Training</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Train the AI on your existing content to match your unique brand voice, tone, and style perfectly.
                </p>
              </CardContent>
            </Card>
            
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => handleSignup('pro')}>
              <CardHeader>
                <Check className="h-10 w-10 text-indigo-600 mb-4" />
                <CardTitle>One-Click Publishing</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">
                  Publish directly to WordPress, Webflow, or your CMS. Schedule posts and manage your content calendar.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Simple, Transparent Pricing</h2>
            <p className="text-xl text-gray-600">Start free, upgrade when you're ready. No hidden fees.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Starter */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-2xl">Starter</CardTitle>
                <div className="text-4xl font-bold text-gray-900">$27<span className="text-lg font-normal text-gray-500">/mo</span></div>
                <p className="text-gray-500">Perfect for solo creators getting started</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> 10,000 AI words/month</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> 5 blog posts</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Social media posts</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Email support</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Basic SEO tools</li>
                </ul>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => handleSignup('starter')}
                >
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
            
            {/* Pro - Featured */}
            <Card className="border-2 border-indigo-600 relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                <Badge className="bg-indigo-600 text-white">Most Popular</Badge>
              </div>
              <CardHeader>
                <CardTitle className="text-2xl">Professional</CardTitle>
                <div className="text-4xl font-bold text-gray-900">$97<span className="text-lg font-normal text-gray-500">/mo</span></div>
                <p className="text-gray-500">For serious content creators and teams</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Unlimited AI words</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Unlimited blog posts</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> All social platforms</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Priority support</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Advanced SEO tools</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Brand voice training</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> API access</li>
                </ul>
                <Button 
                  className="w-full bg-indigo-600 hover:bg-indigo-700"
                  onClick={() => handleSignup('pro')}
                >
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
            
            {/* Annual */}
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-2xl">Annual</CardTitle>
                <div className="text-4xl font-bold text-gray-900">$970<span className="text-lg font-normal text-gray-500">/yr</span></div>
                <p className="text-gray-500">Save 2 months with annual billing</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Everything in Pro</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> 2 months free</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Dedicated account manager</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Custom AI training</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> Team collaboration</li>
                  <li className="flex items-center gap-2"><Check className="h-5 w-5 text-green-500" /> White-label options</li>
                </ul>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => handleSignup('annual')}
                >
                  Start Free Trial
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 px-4 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Loved by Content Creators</h2>
            <p className="text-xl text-gray-600">See what our users are saying about YunikoBot</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4">
                  "This tool has completely transformed my content workflow. I can now produce 3x more content in half the time."
                </p>
                <div className="font-semibold text-gray-900">Sarah Johnson</div>
                <div className="text-gray-500 text-sm">Content Creator</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4">
                  "The SEO optimization features alone are worth the price. My blog traffic has increased 150% since I started using this."
                </p>
                <div className="font-semibold text-gray-900">Mike Chen</div>
                <div className="text-gray-500 text-sm">Marketing Director</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4">
                  "Best investment I've made for my business. The time savings are incredible, and the quality is consistently high."
                </p>
                <div className="font-semibold text-gray-900">Emma Davis</div>
                <div className="text-gray-500 text-sm">Entrepreneur</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">Got questions? We've got answers.</p>
          </div>
          
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">How does the AI understand my brand voice?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Our AI analyzes your existing content to learn your unique writing style, tone, and preferences. You can also provide specific guidelines.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Is the content original and plagiarism-free?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Yes! All content generated is 100% original. Our AI creates unique content based on your inputs.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Can I cancel my subscription anytime?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Absolutely. You can cancel at any time with no questions asked. You'll have access until the end of your billing period.</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Do you offer a free trial?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Yes! We offer a 7-day free trial with full access to all features. No credit card required.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-indigo-600">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to 10x Your Content Output?
          </h2>
          <p className="text-xl text-indigo-100 mb-8">
            Join 10,000+ creators already using YunikoBot
          </p>
          <Button 
            size="lg" 
            className="bg-white text-indigo-600 hover:bg-gray-100 text-lg px-8"
            onClick={() => handleSignup('pro')}
          >
            Start Your Free Trial
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Zap className="h-6 w-6 text-indigo-400" />
                <span className="text-xl font-bold">YunikoBot</span>
              </div>
              <p className="text-gray-400">The AI-powered content creation platform for modern creators.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => scrollToSection('features')} className="hover:text-white">Features</button></li>
                <li><button onClick={() => scrollToSection('pricing')} className="hover:text-white">Pricing</button></li>
                <li><a href="#" className="hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About</a></li>
                <li><a href="#" className="hover:text-white">Blog</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Privacy</a></li>
                <li><a href="#" className="hover:text-white">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            © 2024 YunikoBot. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Signup Dialog */}
      <Dialog open={showSignup} onOpenChange={setShowSignup}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">Start Your Free Trial</DialogTitle>
            <DialogDescription>
              Enter your email to get started with the {selectedPlan} plan.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && submitEmail()}
            />
            <Button 
              className="w-full bg-indigo-600 hover:bg-indigo-700"
              onClick={submitEmail}
              disabled={!email}
            >
              Get Started
            </Button>
            <p className="text-xs text-gray-500 text-center">
              No credit card required. 7-day free trial.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Success Dialog */}
      <Dialog open={showSuccess} onOpenChange={setShowSuccess}>
        <DialogContent className="sm:max-w-md text-center">
          <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <DialogTitle className="text-2xl">You're In! 🎉</DialogTitle>
          <DialogDescription className="text-lg">
            Thanks for signing up! Check your email for next steps.
          </DialogDescription>
          <Button 
            className="mt-4 w-full bg-indigo-600 hover:bg-indigo-700"
            onClick={() => setShowSuccess(false)}
          >
            Got it!
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
