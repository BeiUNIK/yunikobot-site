# Quick Start Guide - Passive Income Automation

Get your automated passive income system running in 15 minutes.

## Prerequisites

- Python 3.9+
- Node.js (for deployment CLI)
- Git

## Step 1: Clone & Setup (2 minutes)

```bash
# Clone the repository
git clone <your-repo-url>
cd passive-income-automation

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## Step 2: Create Free Accounts (5 minutes)

### 1. Supabase (Database)
- Go to [supabase.com](https://supabase.com)
- Sign up with GitHub
- Create new project
- Copy URL and keys from Settings > API

### 2. Stripe (Payments)
- Go to [stripe.com](https://stripe.com)
- Create account
- Get API keys from Developers > API Keys
- Create a product and get Price ID

### 3. SendGrid (Email)
- Go to [sendgrid.com](https://sendgrid.com)
- Sign up (free tier)
- Verify sender email
- Create API key

### 4. OpenAI (AI Content)
- Go to [platform.openai.com](https://platform.openai.com)
- Sign up
- Add payment method
- Create API key

## Step 3: Configure Environment (3 minutes)

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your values
nano .env  # or use your editor
```

Fill in these required values:

```bash
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_KEY=your-anon-key
SUPABASE_SERVICE_KEY=your-service-role-key
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_ID=price_...
SENDGRID_API_KEY=SG.xxx
EMAIL_FROM=noreply@yourdomain.com
OPENAI_API_KEY=sk-...
SECRET_KEY=your-random-secret-key-32-chars
```

## Step 4: Setup Database (2 minutes)

```bash
# In Supabase Dashboard:
# 1. Go to SQL Editor
# 2. Copy contents of database/schema.sql
# 3. Paste and run
```

## Step 5: Deploy (3 minutes)

### Option A: Vercel (Simplest)

```bash
# Install Vercel CLI
npm i -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

### Option B: Railway (With Background Tasks)

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login
railway login

# Initialize
railway init

# Deploy
railcel up
```

## Step 6: Configure Stripe Webhook (2 minutes)

```
1. Go to Stripe Dashboard > Developers > Webhooks
2. Add endpoint: https://your-domain.com/api/v1/payments/webhook
3. Select events:
   - checkout.session.completed
   - invoice.payment_succeeded
   - invoice.payment_failed
   - customer.subscription.created
   - customer.subscription.deleted
4. Copy signing secret to STRIPE_WEBHOOK_SECRET
```

## Step 7: Test Your Setup (1 minute)

```bash
# Test health endpoint
curl https://your-domain.com/health

# Test lead capture
curl -X POST https://your-domain.com/api/v1/leads/capture \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com", "first_name": "Test"}'
```

## You're Live! 🎉

Your automated passive income system is now running.

### Next Steps:

1. **Connect Your Landing Page**
   - Add lead capture form
   - Link to checkout session

2. **Customize Emails**
   - Edit `modules/lead_capture.py`
   - Update email templates

3. **Set Up Monitoring**
   - Configure Slack alerts
   - Set up Sentry (optional)

4. **Test the Flow**
   - Capture a test lead
   - Complete a test payment
   - Verify onboarding emails

### API Endpoints:

```
Health:     GET  /health
Leads:      POST /api/v1/leads/capture
Payments:   POST /api/v1/payments/checkout
Content:    POST /api/v1/content/generate
Dashboard:  GET  /api/v1/admin/dashboard
```

### Daily Operations:

The system automatically:
- ✅ Captures and nurtures leads
- ✅ Processes payments
- ✅ Generates content
- ✅ Onboards customers
- ✅ Sends reports

### Cost Estimate:

| Revenue | Monthly Cost |
|---------|-------------|
| $1,000  | ~$25-40     |
| $5,000  | ~$50-80     |
| $10,000 | ~$100-150   |

---

**Need Help?**
- Check `DEPLOYMENT.md` for detailed instructions
- Review logs in your hosting platform
- Check Sentry for error details
