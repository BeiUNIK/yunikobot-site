# Passive Income Automation System

A production-ready, fully automated system for generating passive income through digital products. Built with Python, FastAPI, and modern cloud services.

## Features

### 1. Lead Capture & Email Automation
- Automated lead collection from landing pages
- Double opt-in email verification
- Welcome email sequences
- Nurture campaigns with scheduled follow-ups
- Email engagement tracking

### 2. Payment Processing
- Stripe integration for subscriptions and one-time payments
- Automated checkout sessions
- Customer portal for subscription management
- Webhook handling for payment events
- Revenue tracking and reporting

### 3. AI Content Generation
- Automated blog post generation
- Email copy creation
- Social media content
- Product descriptions
- SEO-optimized content with keywords

### 4. Customer Onboarding
- 7-step automated onboarding flow
- Progress tracking
- Email reminders for stalled users
- Completion celebration

### 5. Error Handling & Monitoring
- Exponential backoff retry logic
- Circuit breaker pattern
- Slack/email alerts for issues
- Sentry error tracking
- Comprehensive logging

## Tech Stack

| Component | Technology |
|-----------|------------|
| **Backend** | Python, FastAPI |
| **Database** | Supabase (PostgreSQL) |
| **Payments** | Stripe |
| **Email** | SendGrid |
| **AI** | OpenAI GPT-4 |
| **Background Tasks** | Celery + Redis |
| **Hosting** | Vercel / Railway |
| **Monitoring** | Sentry, Loguru |

## Quick Start

```bash
# 1. Clone repository
git clone <repo-url>
cd passive-income-automation

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env with your API keys

# 5. Run locally
uvicorn main:app --reload

# 6. Deploy
vercel --prod  # or railway up
```

## Project Structure

```
passive-income-automation/
├── config/
│   └── settings.py          # Application configuration
├── database/
│   ├── supabase_client.py   # Database client
│   └── schema.sql           # Database schema
├── modules/
│   ├── lead_capture.py      # Lead capture & email automation
│   ├── payment_processor.py # Payment processing
│   ├── content_generator.py # AI content generation
│   └── onboarding.py        # Customer onboarding
├── utils/
│   ├── error_handler.py     # Error handling & retry logic
│   └── alerts.py            # Alert system
├── tasks.py                 # Celery background tasks
├── main.py                  # FastAPI application
├── requirements.txt         # Python dependencies
├── vercel.json              # Vercel deployment config
├── railway.toml             # Railway deployment config
├── .env.example             # Environment variables template
└── DEPLOYMENT.md            # Detailed deployment guide
```

## API Documentation

Once deployed, visit `/docs` for interactive API documentation.

### Key Endpoints

```
# Health Check
GET  /health

# Lead Capture
POST /api/v1/leads/capture
GET  /api/v1/leads/verify

# Payments
POST /api/v1/payments/checkout
POST /api/v1/payments/webhook

# Content
POST /api/v1/content/generate
POST /api/v1/content/schedule

# Onboarding
POST /api/v1/onboarding/{id}/start
GET  /api/v1/onboarding/{id}/progress

# Admin
GET  /api/v1/admin/dashboard
```

## Scheduled Tasks

The system runs these automated tasks:

| Task | Schedule | Description |
|------|----------|-------------|
| Content Pipeline | Daily 9 AM | Generate scheduled content |
| Onboarding Nudges | Daily 2 PM | Remind stalled customers |
| Revenue Report | Daily 11:55 PM | Send daily summary |
| Weekly Analytics | Sunday 9 AM | Weekly business report |

## Cost Breakdown

### Free Tier (Start Here)

| Service | Free Allowance |
|---------|---------------|
| Vercel | 100GB bandwidth |
| Supabase | 500MB database |
| SendGrid | 100 emails/day |
| OpenAI | Pay per use (~$5-20/mo) |
| Stripe | 2.9% + 30¢ per transaction |

### Monthly Cost at Scale

| Revenue | Estimated Costs |
|---------|-----------------|
| $1,000/mo | ~$25-40 |
| $5,000/mo | ~$50-80 |
| $10,000/mo | ~$100-150 |

## Environment Variables

```bash
# Required
SUPABASE_URL=
SUPABASE_KEY=
SUPABASE_SERVICE_KEY=
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
SENDGRID_API_KEY=
OPENAI_API_KEY=
SECRET_KEY=

# Optional
SLACK_WEBHOOK_URL=
SENTRY_DSN=
ALERT_EMAIL=
```

## Error Handling

The system includes multiple layers of error handling:

1. **Retry Logic**: Exponential backoff for transient failures
2. **Circuit Breaker**: Prevents cascading failures
3. **Fallback Values**: Graceful degradation
4. **Alerts**: Slack/email notifications for critical errors
5. **Logging**: Comprehensive logs with Loguru

## Monitoring

### Health Check
```bash
curl https://your-domain.com/health
```

### Dashboard
```bash
curl https://your-domain.com/api/v1/admin/dashboard
```

### Alerts
Configure Slack webhook for real-time alerts on:
- Payment failures
- Automation errors
- High volume events
- Daily/weekly summaries

## Security

- Row Level Security (RLS) in Supabase
- Environment variable secrets
- Stripe webhook signature verification
- Input validation with Pydantic
- CORS configuration

## Customization

### Email Templates
Edit `modules/lead_capture.py` to customize:
- Welcome emails
- Verification emails
- Nurture sequences

### Onboarding Flow
Edit `modules/onboarding.py` to:
- Add/remove steps
- Change timing
- Customize emails

### Content Generation
Edit `modules/content_generator.py` to:
- Change AI prompts
- Add content types
- Adjust tone/style

## Troubleshooting

### Common Issues

**Database Connection Failed**
- Check Supabase URL and keys
- Verify IP allowlist

**Stripe Webhook Errors**
- Verify webhook URL
- Check webhook secret

**Emails Not Sending**
- Verify SendGrid API key
- Check sender verification

**AI Content Fails**
- Check OpenAI API key
- Verify billing setup

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## License

MIT License - See LICENSE file

## Support

For issues and questions:
- Check DEPLOYMENT.md for detailed setup
- Review logs in your hosting platform
- Check Sentry for error details

---

**Built for "Set and Forget" Passive Income Automation**
