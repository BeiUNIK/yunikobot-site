"""
Tests for Lead Capture Module
"""
import pytest
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime

from modules.lead_capture import LeadCaptureManager, LeadCaptureRequest


@pytest.fixture
def mock_supabase():
    """Mock Supabase client"""
    with patch('modules.lead_capture.get_supabase') as mock:
        supabase_mock = Mock()
        mock.return_value = supabase_mock
        yield supabase_mock


@pytest.fixture
def lead_manager(mock_supabase):
    """Create lead manager with mocked dependencies"""
    return LeadCaptureManager()


@pytest.mark.asyncio
async def test_capture_new_lead(lead_manager, mock_supabase):
    """Test capturing a new lead"""
    # Arrange
    mock_supabase.select.return_value = []
    mock_supabase.insert.return_value = {
        'id': 'test-lead-id',
        'email': 'test@example.com'
    }
    
    lead_data = LeadCaptureRequest(
        email='test@example.com',
        first_name='Test',
        source='website'
    )
    
    # Act
    with patch.object(lead_manager.welcome_sequence, 'send_welcome_email', new_callable=AsyncMock):
        with patch.object(lead_manager.welcome_sequence, 'schedule_nurture_sequence', new_callable=AsyncMock):
            result = await lead_manager.capture_lead(lead_data)
    
    # Assert
    assert result.email == 'test@example.com'
    assert result.status == 'pending_verification'
    mock_supabase.insert.assert_called_once()


@pytest.mark.asyncio
async def test_capture_existing_lead(lead_manager, mock_supabase):
    """Test capturing an existing lead"""
    # Arrange
    mock_supabase.select.return_value = [{
        'id': 'existing-id',
        'email': 'test@example.com',
        'status': 'verified'
    }]
    
    lead_data = LeadCaptureRequest(email='test@example.com')
    
    # Act
    result = await lead_manager.capture_lead(lead_data)
    
    # Assert
    assert result.message == "Lead already subscribed"
    mock_supabase.insert.assert_not_called()


@pytest.mark.asyncio
async def test_verify_email_success(lead_manager, mock_supabase):
    """Test successful email verification"""
    # Arrange
    mock_supabase.select.return_value = [{
        'id': 'test-id',
        'email': 'test@example.com',
        'status': 'pending_verification'
    }]
    
    # Act
    with patch.object(lead_manager.welcome_sequence, 'send_verification_success', new_callable=AsyncMock):
        result = await lead_manager.verify_email('valid-token')
    
    # Assert
    assert result is True
    mock_supabase.update.assert_called_once()


@pytest.mark.asyncio
async def test_verify_email_invalid_token(lead_manager, mock_supabase):
    """Test verification with invalid token"""
    # Arrange
    mock_supabase.select.return_value = []
    
    # Act
    result = await lead_manager.verify_email('invalid-token')
    
    # Assert
    assert result is False
