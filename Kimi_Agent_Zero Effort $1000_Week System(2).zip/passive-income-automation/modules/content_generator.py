"""
AI Content Generation Pipeline
Automated content creation using OpenAI API
"""
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
from pydantic import BaseModel
import openai
from slugify import slugify
from loguru import logger

from database.supabase_client import get_supabase
from utils.error_handler import with_retry, fallback, ContentError
from utils.alerts import alert_manager
from config.settings import settings


class ContentRequest(BaseModel):
    """Content generation request"""
    topic: str
    content_type: str = "blog"  # blog, email, social, product
    tone: str = "professional"  # professional, casual, persuasive, educational
    target_audience: Optional[str] = None
    keywords: Optional[List[str]] = []
    word_count: Optional[int] = 800
    include_cta: bool = True
    custom_prompt: Optional[str] = None


class GeneratedContent(BaseModel):
    """Generated content model"""
    id: str
    title: str
    slug: str
    content: str
    excerpt: str
    seo_title: str
    seo_description: str
    keywords: List[str]
    status: str


class ContentGenerator:
    """AI-powered content generation system"""
    
    def __init__(self):
        self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        self.model = settings.OPENAI_MODEL
        self.supabase = get_supabase()
        
        # Content type configurations
        self.content_configs = {
            "blog": {
                "system_prompt": """You are an expert content writer specializing in blog posts. 
                Create engaging, SEO-optimized blog content that provides value to readers.""",
                "default_word_count": 1200,
                "structure": ["introduction", "main_points", "conclusion"]
            },
            "email": {
                "system_prompt": """You are an expert email copywriter. 
                Create compelling emails with high open and click-through rates.""",
                "default_word_count": 300,
                "structure": ["hook", "value_proposition", "cta"]
            },
            "social": {
                "system_prompt": """You are a social media expert. 
                Create engaging, shareable social media posts.""",
                "default_word_count": 150,
                "structure": ["hook", "content", "hashtags"]
            },
            "product": {
                "system_prompt": """You are a product description expert. 
                Create compelling product descriptions that drive sales.""",
                "default_word_count": 400,
                "structure": ["benefits", "features", "cta"]
            }
        }
    
    @with_retry(max_attempts=3, min_wait=2, max_wait=30)
    async def generate_content(self, request: ContentRequest) -> GeneratedContent:
        """
        Generate content using OpenAI
        
        Args:
            request: Content generation parameters
            
        Returns:
            Generated content with metadata
        """
        try:
            config = self.content_configs.get(request.content_type, self.content_configs["blog"])
            word_count = request.word_count or config["default_word_count"]
            
            # Build prompt
            prompt = self._build_prompt(request, config, word_count)
            
            # Generate with OpenAI
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": config["system_prompt"]},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=word_count * 2  # Approximate tokens
            )
            
            generated_text = response.choices[0].message.content
            
            # Parse and structure content
            content_data = self._parse_generated_content(
                generated_text, 
                request.topic,
                request.content_type
            )
            
            # Store in database
            content_record = {
                "title": content_data['title'],
                "slug": content_data['slug'],
                "type": request.content_type,
                "status": "draft",
                "content": content_data['content'],
                "excerpt": content_data['excerpt'],
                "seo_title": content_data['seo_title'],
                "seo_description": content_data['seo_description'],
                "keywords": request.keywords or [],
                "ai_prompt": prompt,
                "ai_model": self.model,
                "generated_at": datetime.utcnow().isoformat(),
                "created_at": datetime.utcnow().isoformat()
            }
            
            result = await self.supabase.insert("content", content_record)
            
            logger.info(f"Content generated: {content_data['title']} ({request.content_type})")
            
            return GeneratedContent(
                id=result['id'],
                title=content_data['title'],
                slug=content_data['slug'],
                content=content_data['content'],
                excerpt=content_data['excerpt'],
                seo_title=content_data['seo_title'],
                seo_description=content_data['seo_description'],
                keywords=request.keywords or [],
                status="draft"
            )
            
        except Exception as e:
            logger.error(f"Content generation failed: {e}")
            await alert_manager.automation_error("content_generation", str(e))
            raise ContentError(f"Failed to generate content: {str(e)}")
    
    def _build_prompt(
        self, 
        request: ContentRequest, 
        config: Dict[str, Any],
        word_count: int
    ) -> str:
        """Build the generation prompt"""
        
        if request.custom_prompt:
            return request.custom_prompt
        
        base_prompt = f"""Create {request.content_type} content about: {request.topic}

Requirements:
- Target length: approximately {word_count} words
- Tone: {request.tone}
"""
        
        if request.target_audience:
            base_prompt += f"- Target audience: {request.target_audience}\n"
        
        if request.keywords:
            base_prompt += f"- Include keywords: {', '.join(request.keywords)}\n"
        
        if request.include_cta:
            base_prompt += "- Include a compelling call-to-action\n"
        
        # Add structure based on content type
        if request.content_type == "blog":
            base_prompt += """

Please provide the content in this format:
TITLE: [Engaging title]
EXCERPT: [2-3 sentence summary]
SEO_TITLE: [SEO-optimized title under 60 chars]
SEO_DESCRIPTION: [Meta description under 160 chars]
CONTENT:
[Full blog post content with proper formatting]
"""
        elif request.content_type == "email":
            base_prompt += """

Please provide the content in this format:
SUBJECT: [Compelling subject line]
PREVIEW: [Preview text under 100 chars]
CONTENT:
[Full email content]
CTA: [Call-to-action button text]
"""
        elif request.content_type == "social":
            base_prompt += """

Please provide the content in this format:
CONTENT:
[Social media post]
HASHTAGS: [Relevant hashtags]
"""
        
        return base_prompt
    
    def _parse_generated_content(
        self, 
        text: str, 
        topic: str,
        content_type: str
    ) -> Dict[str, Any]:
        """Parse the generated content into structured data"""
        
        lines = text.split('\n')
        
        # Default values
        title = topic
        excerpt = ""
        seo_title = topic
        seo_description = ""
        content = text
        
        # Try to extract structured fields
        current_field = None
        field_content = []
        
        for line in lines:
            line_stripped = line.strip()
            
            if line_stripped.startswith('TITLE:'):
                title = line_stripped.replace('TITLE:', '').strip()
            elif line_stripped.startswith('EXCERPT:'):
                excerpt = line_stripped.replace('EXCERPT:', '').strip()
            elif line_stripped.startswith('SEO_TITLE:'):
                seo_title = line_stripped.replace('SEO_TITLE:', '').strip()
            elif line_stripped.startswith('SEO_DESCRIPTION:'):
                seo_description = line_stripped.replace('SEO_DESCRIPTION:', '').strip()
            elif line_stripped.startswith('SUBJECT:'):
                title = line_stripped.replace('SUBJECT:', '').strip()
            elif line_stripped.startswith('CONTENT:'):
                current_field = 'content'
                continue
            elif current_field == 'content':
                field_content.append(line)
        
        if field_content:
            content = '\n'.join(field_content).strip()
        
        # Generate slug
        slug = slugify(title)
        
        # Generate excerpt if not provided
        if not excerpt and content:
            words = content.split()[:50]
            excerpt = ' '.join(words) + '...'
        
        # Generate SEO description if not provided
        if not seo_description:
            seo_description = excerpt[:160] if excerpt else title
        
        return {
            'title': title,
            'slug': slug,
            'content': content,
            'excerpt': excerpt,
            'seo_title': seo_title[:60] if seo_title else title,
            'seo_description': seo_description[:160]
        }
    
    @fallback(fallback_value=[])
    async def get_content_ideas(self, niche: str, count: int = 5) -> List[str]:
        """Generate content ideas for a niche"""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": "You are a content strategist. Generate engaging content ideas."},
                    {"role": "user", "content": f"Generate {count} blog post ideas for the {niche} niche. Return as a numbered list with just the titles."}
                ],
                temperature=0.8,
                max_tokens=500
            )
            
            ideas_text = response.choices[0].message.content
            ideas = [line.strip() for line in ideas_text.split('\n') if line.strip() and line[0].isdigit()]
            
            return ideas[:count]
            
        except Exception as e:
            logger.error(f"Failed to generate content ideas: {e}")
            raise
    
    async def schedule_content_generation(
        self,
        topics: List[str],
        content_type: str = "blog",
        schedule_days: List[int] = None
    ):
        """
        Schedule content generation for multiple topics
        
        Args:
            topics: List of topics to generate content for
            content_type: Type of content to generate
            schedule_days: Days to schedule (0=Monday, 6=Sunday)
        """
        schedule_days = schedule_days or [0, 3]  # Monday and Thursday default
        
        for i, topic in enumerate(topics):
            # Calculate schedule time
            days_ahead = schedule_days[i % len(schedule_days)]
            scheduled_time = datetime.utcnow() + timedelta(days=days_ahead)
            
            # Create content record
            content_record = {
                "title": f"Scheduled: {topic}",
                "type": content_type,
                "status": "scheduled",
                "scheduled_at": scheduled_time.isoformat(),
                "metadata": {"topic": topic, "auto_generate": True},
                "created_at": datetime.utcnow().isoformat()
            }
            
            await self.supabase.insert("content", content_record)
            
            logger.info(f"Content scheduled: {topic} for {scheduled_time.isoformat()}")
        
        # In production, this would trigger a background task
        # celery_app.send_task('generate_scheduled_content')
    
    async def publish_content(self, content_id: str) -> bool:
        """Publish generated content"""
        try:
            await self.supabase.update(
                "content",
                content_id,
                {
                    "status": "published",
                    "published_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat()
                }
            )
            
            logger.info(f"Content published: {content_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to publish content: {e}")
            return False
    
    async def get_content_stats(self) -> Dict[str, Any]:
        """Get content generation statistics"""
        try:
            all_content = await self.supabase.select("content", limit=1000)
            
            return {
                "total_content": len(all_content),
                "published": len([c for c in all_content if c.get('status') == 'published']),
                "draft": len([c for c in all_content if c.get('status') == 'draft']),
                "scheduled": len([c for c in all_content if c.get('status') == 'scheduled']),
                "by_type": self._group_by_type(all_content)
            }
        except Exception as e:
            logger.error(f"Failed to get content stats: {e}")
            return {}
    
    def _group_by_type(self, content_list: List[Dict]) -> Dict[str, int]:
        """Group content by type"""
        types = {}
        for content in content_list:
            content_type = content.get('type', 'unknown')
            types[content_type] = types.get(content_type, 0) + 1
        return types


class ContentPipeline:
    """Automated content pipeline with scheduling"""
    
    def __init__(self):
        self.generator = ContentGenerator()
        self.supabase = get_supabase()
    
    async def run_daily_pipeline(self):
        """Run the daily content generation pipeline"""
        logger.info("Running daily content pipeline")
        
        try:
            # 1. Get scheduled content
            scheduled = await self._get_scheduled_content()
            
            # 2. Generate content for scheduled items
            for item in scheduled:
                topic = item.get('metadata', {}).get('topic', item['title'])
                content_type = item.get('type', 'blog')
                
                request = ContentRequest(
                    topic=topic,
                    content_type=content_type
                )
                
                try:
                    generated = await self.generator.generate_content(request)
                    
                    # Update the scheduled item
                    await self.supabase.update(
                        "content",
                        item['id'],
                        {
                            "title": generated.title,
                            "slug": generated.slug,
                            "content": generated.content,
                            "excerpt": generated.excerpt,
                            "status": "draft",
                            "generated_at": datetime.utcnow().isoformat()
                        }
                    )
                    
                    logger.info(f"Generated scheduled content: {generated.title}")
                    
                except Exception as e:
                    logger.error(f"Failed to generate scheduled content: {e}")
                    continue
            
            # 3. Generate new content ideas if needed
            content_stats = await self.generator.get_content_stats()
            if content_stats.get('scheduled', 0) < 5:
                ideas = await self.generator.get_content_ideas("business growth", 5)
                await self.generator.schedule_content_generation(ideas)
            
            logger.info("Daily content pipeline completed")
            
        except Exception as e:
            logger.error(f"Content pipeline failed: {e}")
            await alert_manager.automation_error("content_pipeline", str(e))
    
    async def _get_scheduled_content(self) -> List[Dict]:
        """Get content scheduled for today"""
        today = datetime.utcnow().date()
        
        all_content = await self.supabase.select(
            "content", 
            {"status": "scheduled"},
            limit=100
        )
        
        # Filter for today's scheduled content
        scheduled_today = []
        for content in all_content:
            scheduled_at = content.get('scheduled_at')
            if scheduled_at:
                scheduled_date = datetime.fromisoformat(scheduled_at.replace('Z', '+00:00')).date()
                if scheduled_date <= today:
                    scheduled_today.append(content)
        
        return scheduled_today


# Global instances
content_generator = ContentGenerator()
content_pipeline = ContentPipeline()
