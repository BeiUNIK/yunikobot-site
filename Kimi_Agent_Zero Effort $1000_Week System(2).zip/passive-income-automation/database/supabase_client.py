"""
Supabase Database Client
Production-ready database operations with retry logic
"""
from supabase import create_client, Client
from supabase.lib.client_options import ClientOptions
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from typing import Optional, Dict, Any, List
from loguru import logger
import os

from config.settings import settings


class SupabaseManager:
    """Singleton Supabase client manager with retry logic"""
    
    _instance: Optional['SupabaseManager'] = None
    _client: Optional[Client] = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._client is None:
            self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Supabase client with service role for admin operations"""
        try:
            # Use service key for backend operations
            key = settings.SUPABASE_SERVICE_KEY or settings.SUPABASE_KEY
            
            options = ClientOptions(
                postgrest_client_timeout=30,
                storage_client_timeout=30,
                schema="public"
            )
            
            self._client = create_client(
                settings.SUPABASE_URL,
                key,
                options=options
            )
            logger.info("Supabase client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Supabase client: {e}")
            raise
    
    @property
    def client(self) -> Client:
        """Get Supabase client instance"""
        if self._client is None:
            self._initialize_client()
        return self._client
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=True
    )
    async def insert(self, table: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Insert data with retry logic"""
        try:
            result = self.client.table(table).insert(data).execute()
            logger.debug(f"Inserted into {table}: {result.data}")
            return result.data[0] if result.data else {}
        except Exception as e:
            logger.error(f"Insert error in {table}: {e}")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=True
    )
    async def update(self, table: str, id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update data with retry logic"""
        try:
            result = self.client.table(table).update(data).eq('id', id).execute()
            logger.debug(f"Updated {table} id={id}")
            return result.data[0] if result.data else {}
        except Exception as e:
            logger.error(f"Update error in {table}: {e}")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=True
    )
    async def select(self, table: str, filters: Dict[str, Any] = None, 
                     limit: int = 100) -> List[Dict[str, Any]]:
        """Select data with filters"""
        try:
            query = self.client.table(table).select('*').limit(limit)
            
            if filters:
                for key, value in filters.items():
                    query = query.eq(key, value)
            
            result = query.execute()
            return result.data or []
        except Exception as e:
            logger.error(f"Select error in {table}: {e}")
            raise
    
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        reraise=True
    )
    async def delete(self, table: str, id: str) -> bool:
        """Delete record by ID"""
        try:
            self.client.table(table).delete().eq('id', id).execute()
            logger.debug(f"Deleted from {table} id={id}")
            return True
        except Exception as e:
            logger.error(f"Delete error in {table}: {e}")
            raise


# Global instance
supabase_manager = SupabaseManager()


def get_supabase() -> SupabaseManager:
    """Get Supabase manager instance"""
    return supabase_manager
