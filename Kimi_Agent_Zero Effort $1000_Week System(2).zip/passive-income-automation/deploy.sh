#!/bin/bash

# Passive Income Automation - Deployment Script
# Usage: ./deploy.sh [vercel|railway]

set -e

PLATFORM=${1:-vercel}

echo "========================================"
echo "Passive Income Automation Deployment"
echo "Platform: $PLATFORM"
echo "========================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if .env exists
if [ ! -f .env ]; then
    echo -e "${RED}Error: .env file not found${NC}"
    echo "Please copy .env.example to .env and fill in your values"
    exit 1
fi

# Check required environment variables
check_env_var() {
    if [ -z "${!1}" ]; then
        echo -e "${RED}Error: $1 is not set in .env${NC}"
        return 1
    fi
    return 0
}

# Load environment variables
export $(grep -v '^#' .env | xargs)

echo ""
echo "Checking environment variables..."

# Required variables
REQUIRED_VARS=(
    "SUPABASE_URL"
    "SUPABASE_KEY"
    "SUPABASE_SERVICE_KEY"
    "STRIPE_SECRET_KEY"
    "STRIPE_WEBHOOK_SECRET"
    "SENDGRID_API_KEY"
    "OPENAI_API_KEY"
    "SECRET_KEY"
)

MISSING=0
for var in "${REQUIRED_VARS[@]}"; do
    if ! check_env_var $var; then
        MISSING=1
    fi
done

if [ $MISSING -eq 1 ]; then
    echo -e "${RED}Please set all required environment variables${NC}"
    exit 1
fi

echo -e "${GREEN}All required environment variables are set${NC}"

# Install dependencies
echo ""
echo "Installing dependencies..."
pip install -q -r requirements.txt

# Run tests if they exist
if [ -d "tests" ]; then
    echo ""
    echo "Running tests..."
    pytest tests/ -v || echo -e "${YELLOW}Warning: Tests failed${NC}"
fi

# Deploy based on platform
case $PLATFORM in
    vercel)
        echo ""
        echo "Deploying to Vercel..."
        
        # Check if Vercel CLI is installed
        if ! command -v vercel &> /dev/null; then
            echo "Installing Vercel CLI..."
            npm install -g vercel
        fi
        
        # Login check
        echo "Checking Vercel login..."
        vercel whoami || vercel login
        
        # Set environment variables
        echo ""
        echo "Setting environment variables..."
        vercel env add SUPABASE_URL production <<< "$SUPABASE_URL"
        vercel env add SUPABASE_KEY production <<< "$SUPABASE_KEY"
        vercel env add SUPABASE_SERVICE_KEY production <<< "$SUPABASE_SERVICE_KEY"
        vercel env add STRIPE_SECRET_KEY production <<< "$STRIPE_SECRET_KEY"
        vercel env add STRIPE_WEBHOOK_SECRET production <<< "$STRIPE_WEBHOOK_SECRET"
        vercel env add STRIPE_PRICE_ID production <<< "$STRIPE_PRICE_ID"
        vercel env add SENDGRID_API_KEY production <<< "$SENDGRID_API_KEY"
        vercel env add EMAIL_FROM production <<< "$EMAIL_FROM"
        vercel env add OPENAI_API_KEY production <<< "$OPENAI_API_KEY"
        vercel env add SECRET_KEY production <<< "$SECRET_KEY"
        
        if [ ! -z "$SLACK_WEBHOOK_URL" ]; then
            vercel env add SLACK_WEBHOOK_URL production <<< "$SLACK_WEBHOOK_URL"
        fi
        
        if [ ! -z "$SENTRY_DSN" ]; then
            vercel env add SENTRY_DSN production <<< "$SENTRY_DSN"
        fi
        
        # Deploy
        echo ""
        echo "Deploying..."
        vercel --prod
        
        echo ""
        echo -e "${GREEN}Deployment to Vercel complete!${NC}"
        ;;
        
    railway)
        echo ""
        echo "Deploying to Railway..."
        
        # Check if Railway CLI is installed
        if ! command -v railway &> /dev/null; then
            echo "Installing Railway CLI..."
            npm install -g @railway/cli
        fi
        
        # Login check
        echo "Checking Railway login..."
        railway whoami || railway login
        
        # Check if project exists
        if ! railway status &> /dev/null; then
            echo "Initializing Railway project..."
            railway init
        fi
        
        # Add Redis if not exists
        echo ""
        echo "Checking Redis..."
        railway add --plugin redis || echo "Redis already exists"
        
        # Set environment variables
        echo ""
        echo "Setting environment variables..."
        railway variables set \
            APP_ENV=production \
            DEBUG=false \
            SUPABASE_URL="$SUPABASE_URL" \
            SUPABASE_KEY="$SUPABASE_KEY" \
            SUPABASE_SERVICE_KEY="$SUPABASE_SERVICE_KEY" \
            STRIPE_SECRET_KEY="$STRIPE_SECRET_KEY" \
            STRIPE_WEBHOOK_SECRET="$STRIPE_WEBHOOK_SECRET" \
            STRIPE_PRICE_ID="$STRIPE_PRICE_ID" \
            SENDGRID_API_KEY="$SENDGRID_API_KEY" \
            EMAIL_FROM="$EMAIL_FROM" \
            OPENAI_API_KEY="$OPENAI_API_KEY" \
            SECRET_KEY="$SECRET_KEY"
        
        if [ ! -z "$SLACK_WEBHOOK_URL" ]; then
            railway variables set SLACK_WEBHOOK_URL="$SLACK_WEBHOOK_URL"
        fi
        
        if [ ! -z "$SENTRY_DSN" ]; then
            railway variables set SENTRY_DSN="$SENTRY_DSN"
        fi
        
        # Deploy
        echo ""
        echo "Deploying..."
        railway up
        
        echo ""
        echo -e "${GREEN}Deployment to Railway complete!${NC}"
        echo ""
        echo "To start background workers:"
        echo "  railway up --service worker"
        echo "  railway up --service scheduler"
        ;;
        
    *)
        echo -e "${RED}Unknown platform: $PLATFORM${NC}"
        echo "Usage: ./deploy.sh [vercel|railway]"
        exit 1
        ;;
esac

# Health check
echo ""
echo "Performing health check..."

# Get deployment URL
if [ "$PLATFORM" == "vercel" ]; then
    DEPLOY_URL=$(vercel ls --meta | grep -o 'https://[^"]*' | head -1)
else
    DEPLOY_URL=$(railway domain)
fi

if [ ! -z "$DEPLOY_URL" ]; then
    echo "Checking health at $DEPLOY_URL/health"
    
    # Wait for deployment to be ready
    sleep 5
    
    HEALTH_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$DEPLOY_URL/health" || echo "000")
    
    if [ "$HEALTH_STATUS" == "200" ]; then
        echo -e "${GREEN}Health check passed!${NC}"
        echo ""
        echo "Your application is live at: $DEPLOY_URL"
        echo ""
        echo "Next steps:"
        echo "1. Update Stripe webhook URL to: $DEPLOY_URL/api/v1/payments/webhook"
        echo "2. Test the API at: $DEPLOY_URL/docs"
        echo "3. Check the dashboard at: $DEPLOY_URL/api/v1/admin/dashboard"
    else
        echo -e "${YELLOW}Health check returned status $HEALTH_STATUS${NC}"
        echo "Please check the logs for errors"
    fi
else
    echo -e "${YELLOW}Could not determine deployment URL${NC}"
fi

echo ""
echo "========================================"
echo -e "${GREEN}Deployment complete!${NC}"
echo "========================================"
